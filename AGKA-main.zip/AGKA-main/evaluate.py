import os
import re
from collections import Counter
import yaml

import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, classification_report
from sklearn.metrics import confusion_matrix, precision_recall_fscore_support
from sklearn.metrics import f1_score
import Levenshtein

from predict import get_label_space
import argparse
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config_path", type=str, required=True, help="Path to the YAML configuration file")
    return parser.parse_args()

def load_config(config_path):
    with open(config_path, 'r') as file:
        config = yaml.safe_load(file)
    return config

# Define a function to extract the label from a string
def extract_label(string):
    pattern = r'{\[(.*?)\]}'
    match = re.search(pattern, string)
    if match:
        return match.group(1)
    else:
        return "NONE"


def extract_labels(task, dataset, df):
    ill_formed_idx, diff_idx = [], []
    if task in ["sc","forum"]:
        true_labels = df["label_text"]
        pred_labels = df["prediction"]
    elif task == "mast":
        if dataset == "stance":
            true_labels = df["label_text"]
            pred_labels = df["prediction"]
        elif dataset in ["emotion", "hate", "irony", "offensive", "compsent19"]:
            true_labels = df["label_text"]
            pred_labels = df["prediction"]
        elif dataset == "implicit":
            true_labels = df["label_text"]
            pred_labels = df["prediction"]
        else:
            raise NotImplementedError
    elif task == "absa":
        if any(substring in dataset for substring in ["uabsa", "aste", "asqp"]):
            true_labels = []
            pred_labels = []
            for i in range(len(df["label_text"])):
                gold_i = eval(df["label_text"][i])
                try:
                    pred_i = eval(df["prediction"][i])
                except:
                    ill_formed_idx.append(i)
                    pred_i = []
                if not isinstance(pred_i, list):
                    pred_i = []
                true_labels.append(gold_i)
                pred_labels.append(pred_i)
        else:
            raise NotImplementedError
    else:
        raise NotImplementedError

    if task != "absa":
        true_labels = [str(i).lower().strip() for i in true_labels]
        pred_labels = [str(i).lower().strip() for i in pred_labels]
        pred_counter = Counter(pred_labels)
        gold_counter = Counter(true_labels)

    return true_labels, pred_labels, ill_formed_idx

def print_counter(freq_dict):
    total_len = sum(freq_dict.values())
    for item, freq in freq_dict.items():
        print(f"{item}: {freq} ({freq/total_len*100:.2f}%)")

def four_list_to_two_list(list):
    new_list = []
    for item in list:
        new_item_list =[]
        for item_list in item:
            new_item_list.append((item_list[0],item_list[3]))
        new_list.append(new_item_list)
    return new_list

def process_acc_recal_f1(labels, predictions, f1_type):
    tp, fp, fn = 0, 0, 0
    epsilon = 1e-7

    acc,precision,recall,f1 = calculate_metrics(labels, predictions,f1_type=f1_type)
    return [acc,precision,recall,f1]

def process_tuple_f1(labels, predictions, verbose=False):
    tp, fp, fn = 0, 0, 0
    epsilon = 1e-7
    labels = four_list_to_two_list(labels)
    predictions = four_list_to_two_list(predictions)

    for i in range(len(labels)):
        gold = set(labels[i])
        try:
            pred = set(predictions[i])
        except Exception:
            pred = set()
        tp += len(gold.intersection(pred))
        fp += len(pred.difference(gold))
        fn += len(gold.difference(pred))
    if verbose:
        print('-'*100)
        print(gold, pred)
    precision = tp / (tp + fp + epsilon)
    recall = tp / (tp + fn + epsilon)
    f1 = 2 * (precision * recall) / (precision + recall + epsilon)
    return [precision,recall,f1]

from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

def calculate_metrics(labels, predictions, f1_type):

    label_names = sorted(set(labels), key=labels.index)
    print(f"label_list_name:{label_names}")
    conf_matrix = confusion_matrix(labels, predictions, labels=label_names)
    print("Confusion Matrix:\n", conf_matrix)

    precision, recall, f1, _ = precision_recall_fscore_support(labels, predictions, labels=label_names,
                                                               average=None)

    accuracy = np.diag(conf_matrix).sum() / conf_matrix.sum()

    print("\nAccuracy: {:.2f}".format(accuracy))
    for label, prc, rec, f1_item in zip(label_names, precision, recall, f1):
        print(f"{label}: Precision: {prc:.2f}, Recall: {rec:.2f}, F1: {f1_item:.2f}")

    acc = accuracy_score(labels, predictions)
    prc = precision_score(labels, predictions, average=f1_type)
    recall = recall_score(labels, predictions, average=f1_type)
    f1 = f1_score(labels, predictions, average=f1_type)

    print(f"sklearn 计算结果：acc {acc},{f1_type},prc{prc},recall{recall},f1{f1}")

    def get_4_point(number):
        return round(number, 4)

    acc=get_4_point(acc)
    prc=get_4_point(prc)
    recall=get_4_point(recall)
    f1=get_4_point(f1)

    return acc,prc, recall,f1

def plot_confusion_matrix(true_labels, pred_labels):
    unique_labels, counts = np.unique(true_labels, return_counts=True)
    sorted_indices = np.argsort(-counts)
    sorted_labels = unique_labels[sorted_indices]

    labels = sorted_labels
    matrix_data = confusion_matrix(true_labels, pred_labels, labels=labels)
    percentage_matrix = matrix_data / matrix_data.sum(axis=1, keepdims=True) * 100

    fig, axs = plt.subplots(1, 1, figsize=(5, 5))

    labels = [label.capitalize() for label in labels]

    sns.heatmap(percentage_matrix, annot=True, cmap='Blues', xticklabels=labels, yticklabels=labels, fmt='.2f',
                ax=axs)
    axs.set_title('Confusion Matrix (%)')
    axs.set_xlabel('Predicted label')
    axs.set_ylabel('True label')

    for text in axs.texts:
        text.set_text(text.get_text() + "%")
        text.set_fontsize(6)

    plt.tight_layout()
    return fig

def replace_string_in_label_list(true_labels):
    processed_labels = [label.lower().replace('_', ' ') for label in true_labels]
    return processed_labels

from typing import List

def process_labels(label_space: List[str], pred_labels: List[str]):
    def parser_classification(predicted_category: str, _categories: List[str]) -> str:
        try:
            # Step 1: Normalize case for input and labels
            normalized_categories = [cat.lower() for cat in _categories]
            normalized_prediction = predicted_category.lower()

            # Step 2: Direct match check
            if normalized_prediction in normalized_categories:
                return _categories[normalized_categories.index(normalized_prediction)]

            # Step 3: Find the last substring match
            matches = {}
            for idx, cat in enumerate(normalized_categories):
                try:
                    matches[idx] = normalized_prediction.rindex(cat)
                except ValueError:
                    continue

            if matches:
                last_match_idx = max(matches, key=matches.get)
                return _categories[last_match_idx]

            # Step 4: Perform fuzzy matching using Levenshtein distance
            levenshtein_distances = [Levenshtein.ratio(normalized_prediction, cat)
                                     for cat in normalized_categories]

            max_ratio = max(levenshtein_distances)
            if max_ratio > 0:  # You might want to add a threshold here
                best_match_idx = levenshtein_distances.index(max_ratio)
                return _categories[best_match_idx]

            # Step 5: Return indication of no match
            return "No_matched"

        except Exception as e:
            print(f"Error in parser_classification: {e}")
            return "No_matched"

    processed_labels = [parser_classification(pred, label_space) for pred in pred_labels]
    return processed_labels

def calculate_metric_and_errors(task, dataset, df, use_soft_match="True", use_process_labels="True", f1_type="weighted", save_confusion_matrix="False"):
    true_labels, pred_labels, ill_formed_idx = extract_labels(task, dataset, df)
    true_labels = replace_string_in_label_list(true_labels)
    pred_labels = replace_string_in_label_list(pred_labels)
    assert len(true_labels) == len(pred_labels)
    confusion_Metrix_figure = None
    label_space = get_label_space(task, dataset)
    label_space = replace_string_in_label_list(label_space)

    if use_soft_match.lower() == "true" and use_process_labels.lower() == "true":
        pred_labels = process_labels(label_space, pred_labels)
        df["process_labels"] = pred_labels
    else:
        df["process_labels"] = pred_labels

    if task in ["sc","forum"]:
        metric = process_acc_recal_f1(true_labels, pred_labels,f1_type)
        metric_name = ["acc","precision", "recall", "f1"]
        if save_confusion_matrix.lower() == "true":
            confusion_Metrix_figure = plot_confusion_matrix(true_labels, pred_labels)
        else:
            confusion_Metrix_figure=None
    elif task == "mast":
        if dataset == "implicit":
            accuracy = accuracy_score(true_labels, pred_labels)
            metric = accuracy
            metric_name = "accuracy"
        elif dataset == "compsent19":
            accuracy =  accuracy_score(true_labels, pred_labels)
            metric = accuracy
            metric_name = "accuracy"
        elif dataset == "stance":
            results = classification_report(true_labels, pred_labels, output_dict=True, zero_division=0)
            f1_against = results['against']['f1-score']
            f1_favor = results['favor']['f1-score']
            stance_f1 = (f1_against+f1_favor) / 2
            metric = stance_f1
            metric_name = "macro f1 (w/t none)"
        elif dataset in ["emotion", "hate", "offensive"]:
            results = classification_report(true_labels, pred_labels, output_dict=True, zero_division=0, labels=label_space)
            macro_f1 = results["macro avg"]["f1-score"]
            metric = macro_f1
            metric_name = "macro f1"
        elif dataset == "irony":
            results = classification_report(true_labels, pred_labels, output_dict=True, zero_division=0)
            irony_f1 = results["irony"]["f1-score"]
            metric = irony_f1
            metric_name = "irony f1"
        else:
            raise NotImplementedError
    elif task == "absa":
        if any(substring in dataset for substring in ["uabsa", "aste", "asqp"]):
            metric = process_tuple_f1(true_labels, pred_labels)
            metric_name = ["precision","recall","f1"]
        else:
            raise NotImplementedError
    else:
        raise NotImplementedError

    error_df = df[df["label_text"] != df["process_labels"]]
    ill_df = df.iloc[ill_formed_idx]

    return metric_name, metric, error_df, ill_df,confusion_Metrix_figure

def process_file(task, dataset_name, dataset_path, config):
    print('-'*100)
    pred_path = os.path.join(dataset_path, "prediction.csv")
    pred_path = pred_path.replace("\\","/")
    df = pd.read_csv(pred_path)
    print(f"pred_path:{pred_path}")
    metric_name, metric, error_df, ill_df,confusion_Metrix_figure = calculate_metric_and_errors(
        task, dataset_name, df, config['use_soft_match'], config['use_process_labels'], config['f1_type'], config['save_confusion_matrix']
    )

    print(f"{metric_name} score for {dataset_name} = {metric}")

    error_file_path = os.path.join(dataset_path, "error.csv")
    error_df.to_csv(error_file_path, index=False)
    figure_path = os.path.join(dataset_path, 'confusion_matrix.png')
    if confusion_Metrix_figure !=None:
        confusion_Metrix_figure.savefig(figure_path, dpi=400)
        print(f"confusion_figure_path:{figure_path}")
    else:
        print(f"dont save figure in path:{figure_path}")

    if len(ill_df) > 0:
        print(f"{len(ill_df)} ill-formed outputs")
        ill_file_path = os.path.join(dataset_path, "ill.csv")
        ill_df.to_csv(ill_file_path, index=False)

    return metric

def prepend_to_keys(input_dict, setting):
    return {f"{setting}{key}": value for key, value in input_dict.items()}

def extract_info(model_group):
    model_name, dataset_name, shot_number,prompt_type = None, None, None,None
    model_name_list = ['random','gpt-3.5-turbo-0125', 'gpt-4-0125-preview', 'llama-v3-70b-instruct', 'llama-v3-8b-instruct', 'mistral-7b-instruct-4k','mixtral-8x7b-instruct']
    dataset_name_list = ['en_forum_2_emotion', 'en_forum_urgent', 'en_forum_epistemic_emotion', 'en_forum_2_opinion',
                         'en_forum_2_question', 'en_forum_coi_cognition']
    prompt_type_list = ['standard','EduTheory']
    # 提取 model_name
    for mn in model_name_list:
        if mn in model_group:
            model_name = mn
            break

    # 提取 dataset_name
    for dn in dataset_name_list:
        if dn in model_group:
            dataset_name = dn
            break
    # 提取 prompt_type
    for pt in prompt_type_list:
        if pt in model_group:
            prompt_type = pt
            break
    # 提取 shot_number
    # 如果含有字符串zero-shot则替换为[shot_0]
    if model_name and dataset_name:
        try:
            shot_number_str = model_group.replace("zero-shot","[shot_0]").split('[shot')[-1]
            shot_number = int(shot_number_str[shot_number_str.find('_')+1:shot_number_str.find(']')])
        except ValueError:
            shot_number = None

    return pd.Series([model_name, dataset_name, shot_number,prompt_type], index=['model_name', 'dataset_name', 'shot_number','prompt_type'])

def save_result_dic(dataset_name,all_results):
    # Prepare data for DataFrame
    # Convert all_results into a format suitable for pandas (list of lists for metrics)
    data = []
    for task, metrics in all_results.items():
        row = [task] + metrics  # Add the task name and its corresponding metrics
        data.append(row)

    # Create a DataFrame with appropriate columns
    data_table = pd.DataFrame(data, columns=["task_dataset", "Accuracy", "Precision", "Recall", "F1_score"])
    extracted_data = data_table['task_dataset'].apply(extract_info)
    grouped_means = pd.concat([data_table, extracted_data], axis=1)

    new_file_path = os.path.join("./outputs", dataset_name + "_metric_macro_processed.xlsx")
    # dataset_name+"results_table_macro_processed.xlsx"
    grouped_means.to_excel(new_file_path, index=False)
    print(dataset_name+"_processed.xlsx saved!")

    # with open(os.path.join("./outputs", dataset_name + "_metric.csv"), 'w') as f:
    #     f.write("task_dataset,Accuracy,Precision,Recall,F1_score\n")
    #     for k, v in all_results.items():
    #         f.write(f"{k}")
    #         for item in v:
    #             f.write(f",{item}")
    #         f.write("\n")


def main():
    args = parse_args()
    config = load_config(args.config_path)

    shots = config['shots']
    selected_tasks = config.get('selected_tasks', ["forum","sc", "mast", "absa"])
    setting_list = config.get('setting_list', ["zero-shot", "majority", "random",'few-shot'])
    selected_datasets = config.get('selected_datasets', [
        "cn_forum_8_emotion","cn_forum_coi_cognition","en_forum_2_emotion","en_forum_2_question",
        "en_forum_confusion","en_forum_urgent",'cn_forum_emotion_and_cognition'
    ])

    for dataset_name in selected_datasets:
        all_results = {}
        for task in selected_tasks:
                for setting in setting_list:
                    if setting in ["zero-shot",  "majority", "random"]:
                        task_output_folder = f"outputs/{setting}/{task}/{dataset_name}/"
                    elif setting == "few-shot":
                        if 'slm_model_name' in config:
                            task_output_folder = f"outputs/{config['slm_model_name'].split('/')[-1]}/{setting}/shot_{shots}/model_{config['model']}/seed_{config['seed']}/{task}/"
                        else:
                            task_output_folder = f"outputs/{setting}/{task}/{dataset_name}/"
                    metric_dict = {}
                    for dataset in sorted(os.scandir(task_output_folder), key=lambda e: e.name):
                        if dataset.is_dir():
                            try:
                                metric_dict[dataset.name] = process_file(task, dataset.name, dataset.path, config)
                            except Exception as e:
                                print(f"Error in path:{dataset.path}, error message: {e}")
                    all_results.update(prepend_to_keys(metric_dict,setting))
                    with open(os.path.join(task_output_folder, "metric.csv"), 'w') as f:
                        f.write("task_dataset,Accuracy,Precision,Recall,F1_score\n")
                        for k, v in metric_dict.items():
                            f.write(f"{setting}_{k}")
                            for item in v:
                                f.write(f",{item}")
                            f.write("\n")
        save_result_dic(dataset_name, all_results)

    return True




if __name__ == "__main__":
    main()
