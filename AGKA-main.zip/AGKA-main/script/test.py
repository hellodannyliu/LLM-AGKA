import itertools
import random

import numpy as np

from evaluate import parse_args


def filter_dictionaries(data_list):
    filtered_data = []

    for item in data_list:
        if ((item.get('setting') == 'random' or item.get('setting') == 'majority') and
                item.get('model_source') == 'chat' and
                item.get('shots') == '1' and
                item.get('prompt_type') == 'standard' and
                item.get('seed') == '42'):
            filtered_data.append(item)
            print(f"{item.get('setting')}\n")
    for item in data_list:
        if ((item.get('setting') == 'zero-shot') and
                item.get('shots') == '1' and
                item.get('seed') == '42'):
            filtered_data.append(item)

    for item in data_list:
        if ((item.get('setting') == 'few-shot') and
                item.get('seed') == '42'):
            filtered_data.append(item)

    return filtered_data


def generate_combinations(selected_tasks=None, ignored_datasets=None, selected_settings=None,
                          model_source_list=None, model_name_dictionary=None, shots_list=None,
                          prompt_type_list=None, seed_list=None, api_key_dic=None, selected_datasets=None):
    selected_tasks = selected_tasks if selected_tasks else ["forum", "sc", "mast", "absa"]
    ignored_datasets = ignored_datasets if ignored_datasets else None

    selected_settings = selected_settings if selected_settings else ["zero-shot", "random", "majority"]

    model_source_list = model_source_list if model_source_list else ["chat", "baidu"]
    model_name_dictionary = model_name_dictionary if model_name_dictionary else {
        'chat': ["gpt-tubor-3.5", "gpt-tubor-4"], "baidu": ["mix_8B"]}
    shots_list = shots_list if shots_list else ["1", "5", "10", "20"]
    prompt_type_list = prompt_type_list if prompt_type_list else ["standard", "EduTheory"]
    seed_list = seed_list if seed_list else ["42", ]
    api_key_dic = api_key_dic if api_key_dic else {'chat': "sk", "baidu": "u1OIVCPf"}
    selected_datasets = selected_datasets if selected_datasets else [
        "cn_forum_8_emotion", "cn_forum_coi_cognition", "en_forum_2_emotion", "en_forum_2_question",
        "en_forum_confusion", "en_forum_urgent", 'cn_forum_emotion_and_cognition', ]

    model_and_keys = [(source, model, api_key_dic[source]) for source in model_source_list for model in
                      model_name_dictionary[source]]

    combinations = list(itertools.product(
        selected_tasks, selected_datasets, selected_settings, model_and_keys, shots_list, prompt_type_list, seed_list
    ))

    formatted_combinations = [{
        'task': combo[0],
        'dataset': combo[1],
        'setting': combo[2],
        'model_source': combo[3][0],
        'model_name': combo[3][1],
        'api_key': combo[3][2],
        'shots': combo[4],
        'prompt_type': combo[5],
        'seed': combo[6]
    } for combo in combinations]

    filter_formatted_combinations = filter_dictionaries(formatted_combinations)
    for combo in filter_formatted_combinations:
        print(combo)

    return filter_formatted_combinations


def main():
    args = parse_args()
    random.seed(args.seed)
    np.random.seed(args.seed)

    selected_tasks = eval(args.selected_tasks) if args.selected_tasks else ["forum", "sc", "mast", "absa"]
    selected_settings = eval(args.setting) if args.setting else ["zero-shot", "random", "majority", "few-shot"]
    model_source_list = eval(args.model) if args.model else ["chat", "baidu"]
    model_name_dictionary = eval(args.model_name) if args.model_name else {'chat': ["gpt-tubor-3.5", "gpt-tubor-4"]}
    shots_list = eval(args.shots) if args.shots else ["1", "5", "10", "20"]
    prompt_type_list = eval(args.prompt_type) if args.prompt_type else ["standard", "EduTheory"]
    seed_list = eval(args.seed) if args.seed else ["42", ]
    api_key_dic = eval(args.api) if args.api else {'chat': "sk-XXX", "baidu": "XXX"}
    selected_datasets = eval(args.selected_datasets) if args.selected_datasets else ["en_forum_2_emotion",
                                                                                     "en_forum_2_question",
                                                                                     "en_forum_confusion",
                                                                                     "en_forum_urgent",
                                                                                     'cn_forum_emotion_and_cognition', ]
    combinations = generate_combinations(selected_tasks=selected_tasks, selected_settings=selected_settings
                                         , model_source_list=model_source_list,
                                         model_name_dictionary=model_name_dictionary
                                         , shots_list=shots_list, prompt_type_list=prompt_type_list, seed_list=seed_list
                                         , api_key_dic=api_key_dic, selected_datasets=selected_datasets)


if __name__ == "__main__":
    main()
