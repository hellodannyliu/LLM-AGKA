# -*- coding:utf-8 -*-


import os
import openai
import pandas as pd
import argparse
import random
import requests
from tqdm import tqdm
import numpy as np
from tenacity import (
    retry,
    stop_after_attempt,
    wait_fixed,
)
import concurrent.futures
import fireworks.client

from groq import Groq

os.environ['TOKENIZERS_PARALLELISM'] = 'false'

import requests
import json


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--num_workers", type=int, default=1, help="Number of samples to use, better under 3")
    parser.add_argument("--setting", type=str, default="zero-shot", help="[zero-shot, few-shot, majority, random]")
    parser.add_argument("--seed", type=int, default=None, help="[0, 1, 42,56,89]")
    parser.add_argument("--shots", type=int, default=None, help="[1, 5, 10]")
    parser.add_argument('--use_api', action='store_true', help='use api or not')
    parser.add_argument("--api", type=str, default=None, help="api key")
    parser.add_argument("--selected_tasks", type=str, default=None, help="list of string of tasks, e.g '[\"sc\"]'")
    parser.add_argument("--selected_datasets", type=str, default=None, help="list of string of datasets")
    parser.add_argument("--ignored_datasets", type=str, default=None, help="list of string of datasets")
    parser.add_argument("--model", type=str, default=None, help="[chat, flant5, flanul2,baidu,groq,fireworks]")
    parser.add_argument("--skip_runned", action="store_true", help="skip runned dataset")
    parser.add_argument("--prompt_name", type=str, default="", help="[zero-shot, few-shot, random]")
    parser.add_argument("--model_name", type=str, default=None,
                        help="[gpt-3.5-turbo, gpt-4-1106-preview,gpt-3.5-turbo-0125,gpt-4-0125-preview,llama-v3-8b-instruct,llama-v3-70b-instruct]")
    parser.add_argument("--prompt_type", type=str, default="", help="[Vanilla, AGKA]")

    return parser.parse_args()


def before_retry_fn(retry_state):
    if retry_state.attempt_number > 1:
        print(f"Retrying API call. Attempt #{retry_state.attempt_number}, f{retry_state}")


def parallel_query_chatgpt_model(args):
    return query_chatgpt_model(*args)


def parallel_query_davinci_model(args):
    return query_davinci_model(*args)




@retry(wait=wait_fixed(10), stop=stop_after_attempt(6), before=before_retry_fn)
def query_chatgpt_model(api_key: str, prompt: str, model_name: str, max_tokens: int = 256, temperature: float = 0):
    
    
    openai.api_key = api_key
    try:
        completions = openai.ChatCompletion.create(
            model=model_name,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=max_tokens,
            n=1,
            stop=None,
            temperature=temperature,
        )
        output = completions.choices[0].message.content.strip()
    except Exception as e:
        print(e)
    return output

def parallel_query_groq_model(args):
    return query_groq_model(*args)

def parallel_query_fireworks_model(args):
    return query_fireworks_model(*args)



@retry(wait=wait_fixed(10), stop=stop_after_attempt(6), before=before_retry_fn)
def query_groq_model(api_key: str, prompt: str, model_name: str, max_tokens: int = 256, temperature: float = 0):
    client = Groq(
        api_key=api_key,
    )

    chat_completion = client.chat.completions.create(
        messages=[
            {
                "role": "user",
                "content": prompt,
                
            }
        ],
        model=model_name,
    )

    output = chat_completion.choices[0].message.content


    return output

@retry(wait=wait_fixed(10), stop=stop_after_attempt(6), before=before_retry_fn)
def query_fireworks_model(api_key: str, prompt: str, model_name: str, max_tokens: int = 256, temperature: float = 0):
    fireworks.client.api_key = api_key
    
    try:
        completion = fireworks.client.ChatCompletion.create(
            f"accounts/fireworks/models/{model_name}",
            messages=[{"role": "user",
                       "content": prompt}],
            temperature=temperature,
            n=1,
            max_tokens=200
        )
        output = completion.choices[0].message.content.strip()
    except Exception as e:
        print(e)
    return output


@retry(wait=wait_fixed(10), stop=stop_after_attempt(6), before=before_retry_fn)
def query_davinci_model(api_key: str, prompt: str, model: str = "text-davinci-003", max_tokens: int = 256,
                        temperature: float = 0):
    openai.api_key = api_key
    try:
        completions = openai.Completion.create(
            model=model,
            prompt=prompt,
            max_tokens=max_tokens,
            temperature=temperature,
            top_p=1.0,
            frequency_penalty=0.0,
            presence_penalty=0.0,
        )
        output = completions.choices[0].text.strip()
    except Exception as e:
        print(e)
    return output


def parallel_query_flant5_model(args):
    return query_flant5(*args)


@retry(wait=wait_fixed(10), stop=stop_after_attempt(6), before=before_retry_fn)
def query_flant5(api_key, prompt):
    model_url = "https://api-inference.huggingface.co/models/google/flan-t5-xxl"
    headers = {"Authorization": f"Bearer {api_key}"}
    payload = {
        "inputs": f"{prompt}",
        "temperature": 0.0
    }
    try:
        response = requests.post(model_url, headers=headers, json=payload)
        pred = response.json()[0]['generated_text'].strip()
    except Exception as e:
        print(response.json())
    return pred


def parallel_query_flanul2_model(args):
    return query_flanul2(*args)


@retry(wait=wait_fixed(10), stop=stop_after_attempt(6), before=before_retry_fn)
def query_flanul2(api_key, prompt):
    model_url = "https://api-inference.huggingface.co/models/google/flan-ul2"
    headers = {"Authorization": f"Bearer {api_key}"}
    payload = {
        "inputs": f"{prompt}",
        "temperature": 0.0
    }
    try:
        response = requests.post(model_url, headers=headers, json=payload)
        pred = response.json()[0]['generated_text'].strip()
    except Exception as e:
        print(response.json())
    return pred



# Get label space
def get_label_space(task: str, dataset: str) -> list:
    label_space=None
    if task == "forum":
        if "en_forum_coi_cognition" in dataset:
            label_space = ['Triggering Event', 'Exploration', 'Integration','Resolution','Other']
            label_space = (label_space)
            return label_space
        if "en_forum_epistemic_emotion" in dataset:
            label_space = ['Neutral','Surprise','Curiosity', 'Enjoyment', 'Anxiety','Confusion']
            label_space = (label_space)
            return label_space
        if "en_forum_2_question" in dataset:
            label_space = ["Include_question", "No_question"]
            label_space = (label_space)
            return label_space
        if "en_forum_2_emotion" in dataset:
            label_space = ['Positive', 'Negative']
            label_space = (label_space)
            return label_space
        if "en_forum_2_opinion" in dataset:
            label_space = ['Contain_opinion', 'No_opinion']
            label_space = (label_space)
            return label_space
        if "en_forum_urgent" in dataset:
            label_space = ['Low_urgency', 'High_urgency']
            label_space = (label_space)
            return label_space
    else:
        raise NotImplementedError
    return sorted(label_space)




def get_task_name(task: str, dataset: str) -> str:
    if task == "forum":
        if "en_forum_coi_cognition" in dataset:
            task_name = "cognitive presence classification in education"
        if "en_forum_epistemic_emotion" in dataset:
            task_name = "epistemic emotion classification in education"
        if "en_forum_2_emotion" in dataset:
            task_name = "sentiment classification in education"
        if "en_forum_2_opinion" in dataset:
            task_name = "opinion detection in education"
        if "en_forum_2_question" in dataset:
            task_name = "question detection in education"
        if "en_forum_urgent" in dataset:
            task_name = "urgency level classification in education"
    else:
        raise NotImplementedError

    return task_name.title()



def generate_template(task_id, label_space, task_name, prompt_type, **kwargs):
    

    if prompt_type == "Vanilla":
        task_definitions = {
          "en_forum_coi_cognition": "Given the text, assign a cognitive presence label from {label_space}.",
            "en_forum_epistemic_emotion": "Given the text, assign a emotion label from {label_space}.",
            "en_forum_2_emotion": "Given the text, assign a emotion label from {label_space}.",
            "en_forum_2_opinion": "Given the text, assign a opinion label from {label_space}.",
            "en_forum_2_question": "Given the text, assign a label from {label_space}. ",
            "en_forum_urgent": "Given the text, assign a urgency level label from {label_space}.",

        }
    elif prompt_type == "AGKA":
        task_definitions = {
            "en_forum_coi_cognition":'''Given the text, assign a cognitive presence label from {label_space}. \nCognitive presence labels are defined as follows. {"Triggering_Event": "the beginning of collective discussions and reflects the initial phase of the inquiry process, such as the presentation of a problem or dilemma.", "Exploration": "learners explore possible solutions to a particular problem, such as searching for information and discussing different ideas. ", "Integration": "Students synthesize new ideas and knowledge through social construction.", "Resolution": "Students solve the original problem, such as evaluating newly created knowledge or applications to practical problems. ", "Other": "It does not belong to the four categories mentioned above."}\n'''
            ,"en_forum_epistemic_emotion": '''Given the text, assign a emotion label from {label_space}. \n The definition of Epistemic Emotions is as follows. {"Surprise": "Feeling astonished and startled by something unexpected.", "Curiosity": "A strong desire to know or learn something.", "Enjoyment": "A feeling of pleasure and happiness.", "Anxiety": "Apprehension, worry, and anxiety.", "Confusion": "Lack of understanding and uncertainty.", "Neutral": "Not involving any emotion."}\n'''
            ,"en_forum_2_emotion":'''Given the text, assign a emotion label from {label_space}. \n The definition of binary emotions is as follows. {"Positive": "the text expresses positive emotions such as surprise, curiosity, enjoyment, pride, hope, and serenity.", "Negative": "The text expresses negative emotions, such as anxiety, frustration, boredom, anger, hopelessness, and shame."}\n'''
            ,"en_forum_2_opinion": '''Given the text, assign a opinion label from {label_space}. \n The definition of opinion is as follows. {"Contain_opinion": “the text expresses an subjective opinion. ","No_opinion": "the text expresses subject matter wholly factual"}\n'''
            ,"en_forum_urgent": '''Given the text, assign a urgency level label from {label_space}. \nThe definition of urgency level is as follows. {"High_urgency": "a high urgency forum post that requires immediate attention from the instructors.", "Low_urgency": "a low urgency forum post that does not require attention from the instructors."}\n'''
            ,"en_forum_2_question": '''Given the text, assign a label from {label_space}. \nThe definition of labels is as follows. { "Include_question": "a sentence that includes a question or are structured as a question. This means the sentence should typically end with a question mark (?) and/or include the typical structure of a question, such as starting with 'what', 'why', 'how', 'do', 'does', 'is', 'are', etc. The sentence should be seeking information, confirmation, or clarification. ", "No_question": "a sentence that does not contain a question"}\n'''

        }
    else:
        raise NotImplementedError
    output_formats = {
        "en_forum_coi_cognition": "Return label only without any other text.",
        "en_forum_epistemic_emotion": "Return label only without any other text.",
        "en_forum_2_emotion": "Return label only without any other text.",
        "en_forum_2_opinion": "Return label only without any other text.",
        "en_forum_2_question": "Return label only without any other text.",
        "en_forum_urgent": "Return label only without any other text.",
    }

    if task_id == "stance":
        task_name += " ({target})".format(**kwargs)
    

    task_definition = task_definitions[task_id].format(**kwargs, label_space=label_space)
    
    output_format = output_formats[task_id]

    return task_name, task_definition, output_format



def generate_fix_demo(train_df, task, dataset):
    tuple_list = []
    if dataset == "compsent19":
        for i, row in train_df.iterrows():
            text = row["text"]
            label = row["label_text"]
            o1, o2, _ = eval(row["tuple"])
            text += f" (compare \"{o1}\" to \"{o2}\")"
            tuple_list.append((text, label))
    elif dataset in ["implicit", "asc_lap14", "asc_rest14"]:
        for i, row in train_df.iterrows():
            text = row["text"]
            label = row["label_text"]
            aspect = row["aspect"]
            text += f" (sentiment towards \"{aspect}\")"
            tuple_list.append((text, label))
    elif dataset == "stance":
        for i, row in train_df.iterrows():
            text = row["text"]
            label = row["label_text"]
            domain = row["domain"]
            text += f" (opinion towards \"{domain}\")"
            tuple_list.append((text, label))
    else:
        sub_df = train_df[['text', 'label_text']]
        tuple_list = [tuple(x) for x in sub_df.to_records(index=False)]
    return tuple_list



def generate_prompt(setting, task, dataset, label_space, row, demo_tuples, prompt_type):
    text = row["text"]
    task_name = get_task_name(task, dataset)

    
    if task == "sc":
        if "asc" in dataset:
            task_name, task_definition, output_format = generate_template("asc", label_space, task_name=task_name,
                                                                          target=row["aspect"])
        else:
            task_name, task_definition, output_format = generate_template("cls", label_space, task_name=task_name)
    elif task == "mast":
        if dataset == "stance":
            task_name, task_definition, output_format = generate_template("stance", label_space, task_name=task_name,
                                                                          target=row["domain"])
        elif dataset in ["irony"]:
            task_name, task_definition, output_format = generate_template("irony", label_space, task_name=task_name)
        elif dataset in ["emotion", "hate", "offensive"]:
            task_name, task_definition, output_format = generate_template("cls", label_space, task_name=task_name)
        elif dataset == "compsent19":
            o1, o2, _ = eval(row["tuple"])
            task_name, task_definition, output_format = generate_template("compsent19", label_space,
                                                                          task_name=task_name, object1=o1, object2=o2)
        elif dataset == "implicit":
            task_name, task_definition, output_format = generate_template("implicit", label_space, task_name=task_name,
                                                                          target=row["aspect"])
        else:
            raise NotImplementedError
    elif task == "absa":
        if "uabsa" in dataset:
            task_name, task_definition, output_format = generate_template("uabsa", label_space, task_name=task_name)
        elif "aste" in dataset:
            task_name, task_definition, output_format = generate_template("aste", label_space, task_name=task_name)
        elif "asqp_mooc_english" in dataset:
            senti_space, cat_space = label_space
            task_name, task_definition, output_format = generate_template("asqp_mooc_english", senti_space,
                                                                          task_name=task_name, cat_space=cat_space)
        elif "asqp" in dataset:
            senti_space, cat_space = label_space
            task_name, task_definition, output_format = generate_template("asqp", senti_space, task_name=task_name,
                                                                          cat_space=cat_space)
        else:
            raise NotImplementedError
    elif task == "forum":
        if "en_forum_coi_cognition" in dataset:
            task_id = "en_forum_coi_cognition"
            task_name, task_definition, output_format = generate_template(task_id, label_space, task_name=task_name,
                                                                          prompt_type=prompt_type)
        elif "en_forum_epistemic_emotion" in dataset:
            task_id = "en_forum_epistemic_emotion"
            task_name, task_definition, output_format = generate_template(task_id, label_space, task_name=task_name,
                                                                          prompt_type=prompt_type)
        elif "en_forum_2_emotion" in dataset:
            task_id = "en_forum_2_emotion"
            task_name, task_definition, output_format = generate_template(task_id, label_space, task_name=task_name,
                                                                          prompt_type=prompt_type)
        elif "en_forum_2_opinion" in dataset:
            task_id = "en_forum_2_opinion"
            task_name, task_definition, output_format = generate_template(task_id, label_space, task_name=task_name,
                                                                          prompt_type=prompt_type)
        elif "en_forum_2_question" in dataset:
            task_id = "en_forum_2_question"
            task_name, task_definition, output_format = generate_template(task_id, label_space, task_name=task_name,
                                                                          prompt_type=prompt_type)
        elif "en_forum_confusion" in dataset:
            task_id = "en_forum_confusion"
            task_name, task_definition, output_format = generate_template(task_id, label_space, task_name=task_name,
                                                                          prompt_type=prompt_type)
        elif "en_forum_on_topic" in dataset:
            task_id = "en_forum_on_topic"
            task_name, task_definition, output_format = generate_template(task_id, label_space, task_name=task_name,
                                                                          prompt_type=prompt_type)
        elif "en_forum_urgent" in dataset:
            task_id = "en_forum_urgent"
            task_name, task_definition, output_format = generate_template(task_id=task_id, label_space=label_space,
                                                                          task_name=task_name, prompt_type=prompt_type)
        elif "cn_forum_emotion_and_cognition" in dataset:
            task_id = "cn_forum_emotion_and_cognition"
            task_name, task_definition, output_format = generate_template(task_id=task_id, label_space=label_space,
                                                                          task_name=task_name, prompt_type=prompt_type)
        else:
            raise NotImplementedError
    else:
        raise NotImplementedError

    if setting == "zero-shot":
        if "cn_" in dataset:
            prompt = f"请执行 {task_name} 任务.\n{task_definition}\n{output_format}\n输入句子:\n{text}"
        else:
            prompt = f"Please perform {task_name} task.\n{task_definition}\n{output_format}\nSentence:\n{text}"
    elif setting == "few-shot":
        if "cn_" in dataset:
            demo_string = ""
            for tup in demo_tuples:
                demo_string += f"\n输入句子:\n{tup[0]}\n标签:{tup[1]}\n"
            prompt = f"请执行 {task_name} 任务.\n{task_definition}\n{output_format}\n{demo_string}\n输入句子:\n{text}\n标签:\n"
        else:
            demo_string = ""
            
            
            
            for tup in demo_tuples:
                demo_string += f"\nText:\n{tup[0]}\nLabel:{tup[1]}\n"
            prompt = f"Please perform {task_name} task.\n{task_definition}\n{output_format}\n{demo_string}\nText:\n{text}\nLabel:\n"
    else:
        raise NotImplementedError
    return prompt


def generate_fake_data(task, dataset, label_space, row):
    
    if any(substring in dataset for substring in ["uabsa", "aste", "asqp"]):
        try:
            pred = [random.choice(eval(row["label_text"]))]
        except:
            pred = []
    else:
        pred = str(random.choice(label_space))
    return pred


def process_dataset(task, dataset, file_path, output_folder, api_key, setting, num_workers, train_path, shots,
                    verbose=False, args=None):
    df = pd.read_csv(file_path)

    if setting in ["few-shot", "majority"]:
        train_df = pd.read_csv(train_path)
    else:
        train_df = None

    print(f"Predict on Setting:{setting},Prompt_type：{args.prompt_type}, Task: {task}, Dataset: {dataset}")
    label_space = get_label_space(task, dataset)

    predictions = []
    prompts = []

    prompt_args = []
    if setting in ["zero-shot", "random", "majority"]:
        demo_tuples = None
    elif setting == "few-shot":
        demo_tuples = generate_fix_demo(train_df, task, dataset)
    else:
        raise NotImplementedError

    max_len = 0
    if setting in ["zero-shot", "few-shot"]:
        if api_key is not None:
            if args.model == "chat":
                parallel_call = parallel_query_chatgpt_model
            elif args.model == "davinci":
                parallel_call = parallel_query_davinci_model
            elif args.model == "flant5":
                parallel_call = parallel_query_flant5_model
            elif args.model == "flanul2":
                parallel_call = parallel_query_flanul2_model
            elif args.model == "fireworks":
                parallel_call = parallel_query_fireworks_model
            elif args.model == "groq":
                parallel_call = parallel_query_groq_model
            else:
                raise NotImplementedError

            for index, row in df.iterrows():
                prompt = generate_prompt(setting, task, dataset, label_space, row, demo_tuples,
                                         prompt_type=args.prompt_type)
                max_len = max(max_len, len(prompt.split()))
                if index == 0:
                    prompt_sample = prompt

                prompt_args.append((api_key, prompt, args.model_name))

            with concurrent.futures.ThreadPoolExecutor(max_workers=num_workers) as executor:
                predictions = list(tqdm(executor.map(parallel_call, prompt_args), total=len(prompt_args),
                                        desc=f"Processing {dataset}"))

            for args in prompt_args:
                prompts.append(args[1])
        else:
            for index, row in tqdm(df.iterrows()):
                prompt = generate_prompt(setting, task, dataset, label_space, row, demo_tuples)
                max_len = max(max_len, len(prompt.split()))
                if index == 0:
                    prompt_sample = prompt
                pred = generate_fake_data(task, dataset, label_space, row)
                prompts.append(prompt)
                predictions.append(pred)
    elif setting in ["random", "majority"]:
        if setting == "majority":
            most_common = train_df["label_text"].value_counts().idxmax()
        for index, row in tqdm(df.iterrows()):
            prompt_sample = ""
            if setting == "random":
                pred = generate_fake_data(task, dataset, label_space, row)
            elif setting == "majority":
                
                pred = most_common
            prompts.append("")
            predictions.append(pred)
    else:
        raise NotImplementedError

    
    if verbose:
        print(prompt)
    df["prediction"] = predictions
    df["prompt"] = prompts

    output_path = os.path.join(output_folder, f"prediction.csv")
    df.to_csv(output_path, index=False)

    return prompt_sample



def process_task(args, task, api_key, selected_datasets=None, ignored_datasets=None):
    setting = args.setting
    num_workers = args.num_workers
    shots = args.shots
    seed = args.seed
    model = args.model

    task_folder = os.path.join("data", f"{task}")

    if setting in ["zero-shot", "random", "majority"]:
        output_task_folder = f"outputs/{setting}/{task}/{selected_datasets}"
        
    elif setting == "few-shot":
        
        output_task_folder = f"outputs/{setting}/{task}/{selected_datasets}"
    else:
        raise NotImplementedError

    prompt_samples = []
    dataset_names = []

    def check_entry(entry, selected_datasets, ignored_datasets):
        return entry.is_dir() and (selected_datasets is None or entry.name in selected_datasets) \
               and (ignored_datasets is None or entry.name not in ignored_datasets)

    entries = (entry for entry in sorted(os.scandir(task_folder), key=lambda e: e.name) if
               check_entry(entry, selected_datasets, ignored_datasets))
    for dataset in entries:
        
        if setting in [ "random", "majority"]:
            output_dataset_folder = output_task_folder + f"/[{task}]_[{setting}]_[{dataset.name}]"
        elif setting in ["zero-shot"]:
            output_dataset_folder = output_task_folder + f"/[{task}]_[{setting}]_[{args.model_name}]_[{dataset.name}]_[{args.prompt_type}]"
        else:
            output_dataset_folder = output_task_folder + f"/[{task}]_[{args.model_name}]_[{args.prompt_type}]_[{setting}]_[{dataset.name}_[shot_{args.shots}]_[{seed}]"

        os.makedirs(output_dataset_folder, exist_ok=True)
        
        file_path = os.path.join(dataset.path, "test.csv")
        
        save_data_path = os.path.join(output_dataset_folder, "prediction.csv")
        if os.path.exists(save_data_path):
            print(f"the dataset of task was predicted！ task saved path: {save_data_path}")
            return True
        if setting in ["zero-shot", "random"]:
            train_path = None
        
        elif setting == "few-shot":
            train_path = os.path.join(dataset.path, f"shot_{shots}", f"seed_{seed}", "train.csv")
        else:
            raise NotImplementedError

        if args.skip_runned:
            pred_file = os.path.join(output_dataset_folder, "prediction.csv")
            if os.path.exists(pred_file):
                print(f"{task} {dataset.name} skiped")
                continue
        if os.name == 'nt':
            output_task_folder = output_task_folder.replace("/", "\\")
        
        prompt_sample = process_dataset(task, dataset.name, file_path, output_dataset_folder, api_key, setting,
                                        num_workers, train_path, shots, args=args)

        prompt_samples.append(prompt_sample)
        dataset_names.append(dataset.name)
    

    os.makedirs(output_task_folder, exist_ok=True)
    prompt_file = os.path.join(output_task_folder, "prompt.txt")

    with open(prompt_file, 'w') as f:
        for task_dataset, prompt in zip(dataset_names, prompt_samples):
            f.write('-' * 100 + '\n')
            f.write(f"{task}-{task_dataset}:\n{prompt}\n\n")


def get_selected_datasets(selected_task):
    forum_dataset_list = [
        "en_forum_coi_cognition",
        "en_forum_epistemic_emotion",
        "en_forum_2_emotion",
        "en_forum_2_opinion",
        "en_forum_confusion",
        "en_forum_urgent",
    ]
    if selected_task == "forum":
        return forum_dataset_list


def main():
    args = parse_args()
    random.seed(args.seed)
    np.random.seed(args.seed)
    

    selected_tasks = eval(args.selected_tasks) if args.selected_tasks else ["forum"]
    ignored_datasets = eval(args.ignored_datasets) if args.ignored_datasets else None
    selected_settings = eval(args.setting) if args.setting else ["zero-shot", "random",  "few-shot"]
    model_source_list = eval(args.model) if args.model else ["chat", "baidu","groq","fireworks"]
    model_name_dictionary = eval(args.model_name) if args.model_name else {'chat': ["gpt-3.5-turbo-0125", "gpt-4-0125-preview"], "fireworks":["mistral-7b-instruct-4k","mixtral-8x7b-instruct","llama-v3-8b-instruct","llama-v3-70b-instruct",]}
    shots_list =  eval(args.shots) if args.shots else ["1", "5", "10",] 
    prompt_type_list = eval(args.prompt_type ) if args.prompt_type else ["Vanilla","AGKA"]
    seed_list = eval(args.seed) if args.seed else ["0","1","42","56","89"]
    api_key_dic = eval(args.api) if args.api else {'chat':"sk-XXX","fireworks":"XX"}
    selected_datasets =  eval(args.selected_datasets) if args.selected_datasets else ['en_forum_2_emotion','en_forum_2_opinion','en_forum_2_question','en_forum_coi_cognition','en_forum_epistemic_emotion','en_forum_urgent']

    from script.test import generate_combinations
    predict_list=generate_combinations(selected_tasks=selected_tasks,selected_settings=selected_settings
                          ,model_source_list=model_source_list,model_name_dictionary=model_name_dictionary
                          ,shots_list=shots_list,prompt_type_list=prompt_type_list,seed_list=seed_list
                          ,api_key_dic=api_key_dic,selected_datasets=selected_datasets)
    

    for item in predict_list:
        task = item['task']
        api_key = item['api_key']
        get_selected_datasets(task)
        args.setting = item['setting']
        args.shots = item['shots']
        args.seed = item['seed']
        args.model = item['model_source']
        selected_datasets = item['dataset']
        args.prompt_type = item['prompt_type']
        args.model_name = item['model_name']
        process_task(args, task, api_key, selected_datasets, ignored_datasets)


if __name__ == "__main__":
    main()

