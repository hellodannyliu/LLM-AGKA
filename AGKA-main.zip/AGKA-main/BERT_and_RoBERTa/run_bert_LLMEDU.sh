#!/bin/bash

datasets=('en_forum_2_emotion' 'en_forum_urgent' 'en_forum_epistemic_emotion' 'en_forum_2_opinion' 'en_forum_2_question' 'en_forum_coi_cognition')
bert_init="roberta-base"
epoch_sample_nums=(10 50 100 200 500 800 1000 -1)
# -1 means full-shot dataset
batch_size=32
is_save_model="no_save"
nb_epochs=50

bert_lr=0.00001

for dataset in "${datasets[@]}"; do
  for seed in 0 1 42 56 89; do
    for epoch_sample_num in "${epoch_sample_nums[@]}"; do
        checkpoint_dir="./checkpoint_llmedu/${bert_init}/${dataset}"
        command="python finetune_bert.py"
        command="$command --dataset ${dataset}"
        command="$command --epoch_sample_num ${epoch_sample_num}"
        command="$command --bert_init ${bert_init}"
        command="$command --checkpoint_dir ${checkpoint_dir}_shots[${epoch_sample_num}]_ranSeed_[${seed}]_time_[${seed}]"
        command="$command --bert_lr ${bert_lr}"
        command="$command --batch_size ${batch_size}"
        command="$command --is_save_model ${is_save_model}"
        command="$command --nb_epochs ${nb_epochs}"
        command="$command --train_random_seed ${seed}"
        echo "Executing command: $command"
        eval $command
    done
  done
done

